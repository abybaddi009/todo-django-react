import React from "react";
import { withRouter } from "react-router-dom";

import CssBaseline from "@material-ui/core/CssBaseline";
import Fab from "@material-ui/core/Fab";

import withStyles from "@material-ui/core/styles/withStyles";

import AddIcon from "@material-ui/icons/Add";

import TodoAddDialog from "components/TodoAddDialog";
import TodoList from "components/TodoList";

const todoItems = [
  {
    id: 1,
    title: "Go to Market",
    description: "Buy ingredients to prepare dinner",
    completed: true
  },
  {
    id: 2,
    title: "Study",
    description: "Read Algebra and History textbook for upcoming test",
    completed: false
  },
  {
    id: 3,
    title: "Sally's books",
    description: "Go to library to rent sally's books",
    completed: true
  },
  {
    id: 4,
    title: "Article",
    description: "Write article on how to use django with react",
    completed: false
  }
];

const styles = theme => ({
  fab: {
    position: "absolute",
    bottom: theme.spacing.unit * 2,
    right: theme.spacing.unit * 2
  }
});

class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      viewCompleted: false,
      todoList: todoItems,
      todoAddDialog: false
    };
  }

  displayCompleted = status => {
    if (status) {
      return this.setState({ viewCompleted: true });
    }
    return this.setState({ viewCompleted: false });
  };

  handleDeleteTodo = id => {
    var todoList = this.state.todoList.filter(todo => todo.id !== id);
    this.setState({
      todoList: todoList
    });
  };

  handleTodoAddToList = todo => {
    var todoList = [...this.state.todoList, todo];
    this.setState({
      todoList: todoList
    });
  };

  openTodoAddDialog = event => {
    this.setState({ todoAddDialog: true });
  };

  closeTodoAddDialog = event => {
    this.setState({ todoAddDialog: false });
  };

  render() {
    const { classes } = this.props;
    return (
      <React.Fragment>
        <CssBaseline />
        <TodoList
          todoList={this.state.todoList}
          handleDeleteTodo={this.handleDeleteTodo}
        />
        <Fab
          color="primary"
          aria-label="Add"
          className={classes.fab}
          onClick={this.openTodoAddDialog}
        >
          <AddIcon />
        </Fab>
        <TodoAddDialog
          open={this.state.todoAddDialog}
          onClose={this.closeTodoAddDialog}
          handleTodoAddToList={this.handleTodoAddToList}
        />
      </React.Fragment>
    );
  }
}

export default withRouter(withStyles(styles)(Dashboard));
