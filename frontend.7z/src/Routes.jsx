import React, { Component } from 'react';
import { Switch, Route, Redirect } from 'react-router-dom';

// Views
import Dashboard from './views/Dashboard';

export default class Routes extends Component {
  render() {
    return (
      <Switch>
        <Redirect
          exact
          from="/"
          to="/todos"
        />
        <Route
          component={Dashboard}
          exact
          path="/todos"
        />
        <Redirect to="/not-found" />
      </Switch>
    );
  }
}
