import React from "react";
import { withRouter } from "react-router-dom";

import Grid from "@material-ui/core/Grid";

import withStyles from "@material-ui/core/styles/withStyles";

import TodoView from "components/TodoView";

const styles = theme => ({
  grid: {
    width: 1200,
    marginTop: 40,
    [theme.breakpoints.down("sm")]: {
      width: "calc(100% - 20px)"
    }
  },
  grid_item: {
    padding: theme.spacing.unit * 3
  }
});

const TodoList = props => {
  const { classes, todoList, handleDeleteTodo } = props;
  return (
    <Grid
      spacing={24}
      alignItems="center"
      justify="center"
      container
      className={classes.grid}
    >
      {todoList.map(todo => (
        <Grid item xs={12} md={4} className={classes.grid_item}>
          <TodoView todo={todo} handleDeleteTodo={handleDeleteTodo} />
        </Grid>
      ))}
    </Grid>
  );
};

export default withRouter(withStyles(styles)(TodoList));
