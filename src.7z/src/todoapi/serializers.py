from rest_framework import serializers

from .models import Project, Team

class TeamSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=128)
    description = serializers.CharField(max_length=512, allow_null=True)
    slug = serializers.CharField(max_length=128)

    class Meta:
        fields = ('id',
                  'name',
                  'description',
                  'slug')
        model = Team

class ProjectSerializer(serializers.ModelSerializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField(max_length=128)
    description = serializers.CharField(max_length=512, allow_null=True)
    slug = serializers.CharField(max_length=128)
    team = TeamSerializer(many=True)

    class Meta:
        fields = ('id',
                'name',
                'description',
                'slug',
                'team')
        model = Project


