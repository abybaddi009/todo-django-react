from django.urls import path

from .views import ProjectCL, ProjectRUD, TeamCL, TeamRUD

urlpatterns = [
    path("projects/", ProjectCL.as_view(), name="ProjectCL"),
    path("projects/<int:pk>/", ProjectRUD.as_view(), name="ProjectRUD"),
    path("teams/", TeamCL.as_view(), name="TeamCL"),
    path("teams/<int:pk>/", TeamRUD.as_view(), name="TeamRUD")
]
