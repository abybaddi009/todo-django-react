from django.apps import AppConfig


class TodoapiConfig(AppConfig):
    name = 'ProjectLab'
