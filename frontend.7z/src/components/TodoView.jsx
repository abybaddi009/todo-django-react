import React from "react";
import PropTypes from "prop-types";
import { withStyles } from "@material-ui/core/styles";
import Card from "@material-ui/core/Card";
import CardActions from "@material-ui/core/CardActions";
import CardContent from "@material-ui/core/CardContent";
import Fab from "@material-ui/core/Fab";
import Edit from "@material-ui/icons/Edit";
import DeleteIcon from "@material-ui/icons/Delete";
import Typography from "@material-ui/core/Typography";

const styles = theme => ({
  card: {
    minWidth: 275,
    margin: theme.spacing.unit * 2
  },
  bullet: {
    display: "inline-block",
    margin: "0 2px",
    transform: "scale(0.8)"
  },
  title: {
    fontSize: 14
  },
  pos: {
    marginBottom: 12
  },
  fab: {
    margin: theme.spacing.unit
  }
});

function SimpleCard(props) {
  const { classes, todo, handleDeleteTodo } = props;

  return (
    <Card className={classes.card}>
      <CardContent>
        <Typography variant="h5" component="h2">
          {todo.title}
        </Typography>
        <Typography component="p">{todo.description}</Typography>
      </CardContent>
      <CardActions>
        <Fab color="secondary" aria-label="Edit" className={classes.fab}>
          <Edit />
        </Fab>
        <Fab aria-label="Delete" className={classes.fab}>
          <DeleteIcon onClick={() => handleDeleteTodo(todo.id)} />
        </Fab>
      </CardActions>
    </Card>
  );
}

SimpleCard.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(SimpleCard);
